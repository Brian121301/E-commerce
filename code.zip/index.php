<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jules Crafting Corner</title>
    <link rel="stylesheet" href="./assets/css/style.css">
</head>

<body>
    <header>
        <img src="C:\Users\palme\OneDrive\Desktop\Mp.html\01DEC706-3183-4853-8AB2-EBCCD27D8118.jpg" alt="Jules Crafting Corner Logo" height="120" width="120">
        <a href="index.php">
            <h1>Jules Crafting Corner</h1>
        </a>
    </header>

    <nav>
        <a href="./gallery.php">Gallery</a>
        <a href="./login.php">Login</a>
        <a href="./products.php">Product Listing</a>
        <a href="./cart.php">Shopping Cart</a>
    </nav>

    <section>
        <p>Welcome to Jules Crafting Corner! Explore our creative world.</p>
        <!-- Add more content as needed -->
    </section>

    <footer>
        <p>&copy; 2024 Jules Crafting Corner</p>
    </footer>
</body>

</html>